function fnValidateNewUserRegistration(f){
	$("span.error").text("");
	var isValid = true;

	var firstname = f.firstname.value;
	firstname = firstname.trim() || firstname;
	if(firstname.length==0){
		$("#error_firstname").text("Firstname is required");
		isValid = false;
	}

	var lastname = f.lastname.value;
	lastname = lastname.trim() || lastname;
	if(lastname.length==0){
		$("#error_lastname").text("Lastname is required");
		isValid = false;
	}

	var cellphone = f.cellphone.value;
	cellphone = cellphone.trim() || cellphone;
	if(!cellphone.match(/^\d{10}$/g)){
		$("#error_cellphone").text("Please enter a valid cellphone number");
		isValid = false;
	}
	$.ajax({
		url: "check_phone_already_used.php",
		method: "GET",
		async: false,
		data: {
			cellphone: cellphone
		},
		success: function(data){
			if(!data.status){
				$("#error_cellphone").text("This phone is already registered with us");
				isValid = false;
			}
		}
	});

	var email = f.email.value;
	var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(!re.test(email)){
    	$("#error_email").text("Please enter a valid email id");
		isValid = false;
    }
    $.ajax({
		url: "check_email_already_used.php",
		method: "GET",
		async: false,
		data: {
			email: email
		},
		success: function(data){
			if(!data.status){
				$("#error_email").text("This email is already registered with us");
				isValid = false;
			}
		}
	});

	var username = f.username.value;
	username = username.trim() || username;
	if(username.length==0){
		$("#error_username").text("Username is required");
		isValid = false;
	}

	$.ajax({
		url: "check_username_availability.php",
		method: "GET",
		async: false,
		data: {
			username: username
		},
		success: function(data){
			if(!data.status){
				$("#error_username").text("This username is already taken");
				isValid = false;
			}
		}
	});

	var password = f.password.value;
	password = password.trim() || password;
	if(password.length==0){
		$("#error_password").text("Password is required");
		isValid = false;
	}

	var confirm_password = f.confirm_password.value;
	confirm_password = confirm_password.trim() || confirm_password;
	if(confirm_password.length==0){
		$("#error_confirm_password").text("Password confirmation is required");
		isValid = false;
	}

	if(password!=confirm_password){
		$("#error_confirm_password").text("Passwords don't match.");
		isValid = false;
	}

	var type = $("#type").val();
	if(type==-1){
		$("#error_type").text("Please select a type");
		isValid = false;
	}

	var human_check = f.human_check.value;
	human_check = human_check.trim() || human_check;
	var re = /^\d+$/;
	if(human_check.length==0 || !re.test(human_check)){
		$("#error_human_check").text("Please enter a number.");
		isValid = false;
	}
	else if(window.human_check_result!=human_check){
		$("#error_human_check").text("OOPS! You got it wrong this time.");
		isValid = false;
	}

	return isValid;
}

function fnCheckUsernameAvailability(){
	$("#error_username").text("");
	$("#availability").html("");

	var username = $("#username").val();
	username = username.trim() || username;
	if(username.length==0){
		$("#error_username").text("Please enter a username before checking for availability");
		return;
	}

	$.ajax({
		url: "check_username_availability.php",
		method: "GET",
		data: {
			username: username
		},
		success: function(data){
			if(data.status){
				$("#availability").html("<img src='images/available.png' />");
			}
			else{
				$("#availability").html("<img src='images/not-available.png' />");
			}
		}
	});

}