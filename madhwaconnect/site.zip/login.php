<?php

	include_once "config.php";
	if (session_status() == PHP_SESSION_NONE) {
		session_start();
	}
	if(!isset($_POST["username_email"])){
		header("Location: ./index.php");
		return;
	}

	$username = $_POST["username_email"];
	$password = $_POST["password"];


	$sql = "select * from users where ? in (username, email, another_email) and password=md5(?)";
	$data = R::getRow($sql, array($username, $password));
	if(count($data)==0){
		header("Location: ./index.php");
		$_SESSION["login_error"] = "Invalid username/password";
		return;
	}
	else{
		if (session_status() == PHP_SESSION_NONE) {
			session_start();
		}
		$_SESSION["current_user"] = $data;
		header("Location: ./index.php");

		if(isset($_POST["keep_me_logged_in"])){
			// user wants to be remembered by the browser
			// send a kookie
			setcookie("token", $data["id"], time()+365*24*60*60);
		}
		else{

		}
		return;
	}