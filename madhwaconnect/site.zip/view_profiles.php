<?php include_once "header.php"; ?>
<div id="main">
<?php
	// view_profiles.php
	


	include_once "config.php"; 
	$sql = "select * from users";
	if(isset($_REQUEST["type"])){
		$type = $_REQUEST["type"];
		$sql .= " where type=" . $type;

		?>
		<h1><a class="home" href="/" title="Home">
		<img border="0" src="images/home.png"/></a>
		List of <?php echo $types_map[$type]; ?></h1>

		<div id="quick_links">
			<ul>
				<?php
				foreach ($types_map as $index => $value) {
					if($index==1 || $index==$type) continue;
					?>
				<li>
					<a href="?type=<?php echo $index;?>" title="<?php echo $value;?>">
						<?php echo $value;?></a>
				</li>
					<?php
				}
				?>

			</ul>
		</div>

		<div class="gap"></div>
		<?php
		if(!$user_loggedin){
		?>
		<div id="loginDiv">
			<script type="text/javascript" src="script/login.js"></script>
			<form>
				Login to view full details:
				<input type="text" name="username_email" placeholder="Username/Email" />
				<input type="password" name="password" placeholder="Password" />
				<button type="button" class="submit" onclick="fnLoginAjax(this.form)">Login</button>
				<span id="login_err" class="error"></span>
			</form>

		</div>
		<?php
		}
		?>

		<div class="gap"></div>


		<?php
	}
	$sql .= " order by firstname";

	$data = R::getAll($sql);
	foreach($data as $d){
		$name = "{$d["firstname"]} {$d["lastname"]}";
		$email = "{$d["email"]}";
		$cellphone = "{$d["cellphone"]}";

		if(!$user_loggedin){
			$size = strlen($email);
			$email = substr($email, 0, 5) . str_pad("", 5, "*") . substr($email, $size-5);
			$cellphone = substr($cellphone, 0, 3) . str_pad("", 4, "*") . substr($cellphone, 7);
		}
		?>

		<div class="one_profile">
			<fieldset>
				<div class="basic_info">
					<?php
						$profile_picture = "images/profile/default.jpg";
						if($d["profile_picture"]!=null){
							$profile_picture = $d["profile_picture"];
						}
					?>
					<img src="<?php echo $profile_picture; ?>" 
						class="profile_picture" 
						title = "<?php echo $name;?>" />

					<div>
						<div><label>Name</label>: 
							<?php echo $name;?></div>
					</div>
					<div>
						<div><label>Email</label>: 
							<?php echo $email;?></div>
					</div>
					<div>
						<div><label>Cellphone</label>: 
							<?php echo $cellphone;?></div>
					</div>

					<div class="action_bar">
						<a href="javscript:void()" 
							onclick="fnCommunicate(<?php echo $d["id"];?>, 'email')">
							<img src="images/email.jpg" title="Send an email"/>
						</a>
						<a href="javscript:void()" 
							onclick="fnCommunicate(<?php echo $d["id"];?>, 'sms')">
							<img src="images/sms.jpg" title="Send an SMS" />
						</a>
						<a href="javascript:void()" 
							onclick="fnCommunicate(<?php echo $d["id"];?>, 'message')">
							<img src="images/message.jpg" title="Send a message" />
						</a>
					</div>
					
				</div>

				<div class="description">
					<?php echo $d["additional_info"];?>
				</div>
			</fieldset>
		</div>
		<?php
		
	}
?>
</div>
<script type="text/javascript">
	$(function(){
		$(".action_bar").hide();
		$(".one_profile").on("mouseover", function(){
			$(this).find(".action_bar").show();
		}).on("mouseout", function(){
			$(this).find(".action_bar").hide();
		});
	});
</script>
<?php include_once "footer.php"; ?>