<?php include_once "check_for_auto_login.php"; ?>
<?php

	function endsWith($haystack, $needle){
		return $needle === "" || substr($haystack, -strlen($needle)) === $needle;
	}

	if (session_status() == PHP_SESSION_NONE) {
		session_start();
	}
	
	if(isset($_SESSION["current_user"])){
		$current_user = $_SESSION["current_user"];
		$current_user_fullname = $current_user["firstname"] . " " . $current_user["lastname"];
		$user_loggedin = true;
	}
	else{
		$user_loggedin = false;
	}
?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8" />

	<style type="text/css">
		@import "css/default.css";
		@import /**/"ezmenuapi/jquery.ez.menu.min.css";

	</style>

	<script src="jquery/jquery-2.1.1.min.js">
	</script>

	<script src="ezmenuapi/jquery.ez.menu.min.js">
	</script>

	<!--
<script type="text/javascript" src="script/menu.js">
	</script>
-->


	<title>Madhwa Connect</title>

</head>
<body>

<div id="container">
		<?php if($user_loggedin && !endsWith($_SERVER["SCRIPT_NAME"], "/index.php")){
			$current_user_profile_picture = "./images/profile/default.jpg";

			if($current_user["profile_picture"]!=""){
				$current_user_profile_picture = $current_user["profile_picture"];
			}
		?>
		<div class="cpanel">
			
			<div>
			<a href="dashboard.php">
			<img src="<?php echo $current_user_profile_picture; ?>" 
				class="profile_picture"
				title="<?php echo $current_user_fullname; ?>" />
			</a>
			</div>
			<div style="padding-left: 5px;">
				<a href="logout.php">Logout</a>
			</div>
		</div>	
		<?php
		}
		?>
		<img src="images/logo.png" class="logo" />

		<?php

		if($_SERVER["SCRIPT_NAME"]=="/index.php"){

		}
		else{

		}
		?>

