

</div><!-- end of container -->

<!-- testing for message -->
<?php
	if(isset($_SESSION["message"])){
		$msg = $_SESSION["message"];
		?>
		<script type="text/javascript">
			window.alert("<?php echo $msg; ?>");
			$("#username_email").select().focus();
		</script>
		<?php	
		unset($_SESSION["message"]);
	}
	
?>

</body>
</html>