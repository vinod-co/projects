<?php include_once "header.php";?>

<div id="main">
	<h2><a class="home" href="/" title="Home"><img border="0" src="images/home.png"/></a>
		Your registration details have been accepted</h2>
	
	<form class="classic">
	<fieldset>
		<legend>What next?</legend>
	

	<p>
		Just one more step to follow.
	</p>
	<p>
		As part of our anti-spam policy, we have sent an mail to your registered email address. 
		You will receive the same in a while. Please check your "Junk Mail" folder also. 

	</p>
	<p>
		Please click the confirmation link in the email to complete the registration process. 
	</p>

	<p>
		You may close this window now.
	</p>

	</fieldset>
	</form>
</div>


<?php include_once "footer.php";?>