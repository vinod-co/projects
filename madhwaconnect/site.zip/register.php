<?php include_once "header.php"; ?>

<?php
	$num1 = rand(0, 9);
	$num2 = rand(0, 9);

	if($num2>$num1){
		$temp = $num1;
		$num1 = $num2;
		$num2 = $temp;
	}

	$op = substr("+-", rand(0,1), 1);

	$human_check_expr = "{$num1} {$op} {$num2}";
	$result = eval("return ({$num1} {$op} ${num2});");
?>

<script type="text/javascript">
	window.human_check_result = <?php echo $result; ?>;
</script>

<div id="register">
<script type="text/javascript" src="script/new_user_validation.js"></script>
	<h1><a class="home" href="/" title="Home">
		<img border="0" src="images/home.png"/></a>
		New user registration</h1>

	<form class="classic" method="POST" 
		action="process_registration.php"
		onsubmit="return fnValidateNewUserRegistration(this);">
		<fieldset>
			<legend>Please fill the form</legend>
			<p>
				<label>Firstname</label>
				<input type="text" id="firstname" name="firstname" >
				<span class="error" id="error_firstname"></span>
			</p>

			<p>
				<label>Lastname</label>
				<input type="text" id="lastname" name="lastname" />
				<span class="error" id="error_lastname"></span>
			</p>

			<p>
				<label>Cellphone</label>
				<input type="text" id="cellphone" name="cellphone" />
				<span class="error" id="error_cellphone"></span>
			</p>

			<p>
				<label>Email</label>
				<input type="text" id="email" name="email" style="width: 400px" />
				<span class="error" id="error_email"></span>
			</p>

			<p>
				<label>Desired username</label>
				<input type="text" id="username" name="username" />
				<a href="javascript:void()" onclick="fnCheckUsernameAvailability()">Available?</a>
				<span id="availability"></span>
				<span class="error" id="error_username"></span>
			</p>

			<p>
				<label>Password</label>
				<input type="password" id="password" name="password" />
				<span class="error" id="error_password"></span>
			</p>

			<p>
				<label>Confirm password</label>
				<input type="password" id="confirm_password" name="confirm_password" />
				<span class="error" id="error_confirm_password"></span>
			</p>

			<p>
				<label>Type</label>
				<select name="type" id="type">
					<option value="-1"></option>
					<option value="1">Consumer</option>
					<option value="2">Pandit/Purohit</option>
					<option value="3">Food caterer</option>
					<option value="4">Flower decorater</option>
					<option value="5">Musician</option>
					<option value="6">Wedding hall owner</option>
				</select>
				<span class="error" id="error_type"></span>
			</p>
				<label>What is <?php echo $human_check_expr;?> ?</label>
				<input type="text" id="human_check" name="human_check"
					placeholder="Not a robot :-)" />
				<span class="error" id="error_human_check"></span>
			</p>

			<p>
				<button class="submit">Register</button>

				<a href="/" class="home">Cancel</a>
			</p>

			<p class="note">
				Note: All fields are mandatory
			</p>
		</fieldset>
	</form>
</div>
<?php include_once "footer.php"; ?>