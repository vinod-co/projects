<?php

include_once "config.php";

$is_valid = true;

// set $is_valid = false, if any of the following fails

// get all inputs
$firstname = trim($_POST["firstname"]);
$lastname = trim($_POST["lastname"]);
$cellphone = trim($_POST["cellphone"]);
$email = trim($_POST["email"]);
$username = trim($_POST["username"]);
$password = trim($_POST["password"]);
$confirm_password = trim($_POST["confirm_password"]);
$type = trim($_POST["type"]);
$human_check = trim($_POST["human_check"]);

// check for empty inputs
if(strlen($firstname)==0){
	
}
// check for numerics in phone
// check for email pattern
// check for existence of phone
// check for existence of email
// check for existence of username

if($is_valid){
	unset($_POST["confirm_password"]);
	unset($_POST["human_check"]);

	$new_user = R::dispense("users");
	$new_user->import($_POST);
	$new_user->date_of_registration = date('Y-m-d h:i:s');
	R::store($new_user);
	header("Location: next_step.php");	
}
else{

}

?>

